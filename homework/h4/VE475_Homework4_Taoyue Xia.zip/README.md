# VE475 Homework4

## Ex3.4

The ***code, CmakeList***, and ***Makefile*** are included in the folder ```ex3```, realizing the function of Modular exponentiation.

To generate the executive file, just enter the folder and use command ```make``` in the terminal, then run ```./ex3_4``` it will show the result of Ex3.4. 

In case of failure of ***Makefile***, you can run ```cmake ./``` to regenerate the ***Makefile***, and run the code.

The output should be:

**The final modulo is: 8190**

